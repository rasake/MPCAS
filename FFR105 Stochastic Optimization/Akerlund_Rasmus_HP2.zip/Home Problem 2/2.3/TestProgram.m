clear all
clc
global TRUCKMASS MAX_T AMBIENT_T TAU Ch Cb STEP_SIZE MAX_SPEED MAX_ALPHA
global START_SPEED START_GEAR START_T
global NBR_HIDDEN_NEURONS BETA

TRUCKMASS = 20000; %kg
MAX_T = 750; %Kelvin
AMBIENT_T = 283; %Kelvin
TAU = 30; %seconds
Ch = 40; %K/s
Cb = 3000; %N
MAX_SPEED = 25; %m/s
MAX_ALPHA = 10; %degrees
START_SPEED = 20; %m/s
START_GEAR = 7;
START_T = 500; %K
STEP_SIZE = 0.01;
NBR_HIDDEN_NEURONS = 3;
BETA = 0.2;
slope = 1;
set = 2;

bestChromosome = [0.57166 -0.89989 -0.48975 -0.96616 -1.0252 -0.94275 -0.99449 -1.1433 -0.46179 0.0083712 0.49198 1.7102 0.60943 -0.97864 -0.48817 -0.53009 0.28877 1.0852 1.3224 -0.89156]


[x, speed, brakeT, brakePressure, gear] = RunSlopeDetailed(bestChromosome, slope, set);

if set == 2
    titleStr = ['Running the best network on slope ' num2str(slope) ' in the test set'];
else
    titleStr = ['Running the best network on slope ' num2str(slope) ' in the set' num2str(set)];
end

subplot(5,1,1)
plot(x,GetSlopeAngle(x, slope, set))
ylabel('Alpha')
title(titleStr)

subplot(5,1,2)
plot(x(1:end-1),brakePressure)
ylabel('Brake Pressure')

subplot(5,1,3)
plot(x(1:end-1),gear)
ylabel('gear')

subplot(5,1,4)
plot(x,speed)
ylabel('speed')

subplot(5,1,5)
plot(x,brakeT)
xlabel('x')
ylabel('Brake Temp.')

